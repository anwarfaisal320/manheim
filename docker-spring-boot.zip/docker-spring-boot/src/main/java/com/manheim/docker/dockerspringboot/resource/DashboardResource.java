package com.manheim.docker.dockerspringboot.resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/manheim/dashboard")
public class DashboardResource {
	
	@GetMapping
	public String dashboard() {
		
		return "Welcome to Manheim! Dashboard app is in progress...";
	}

}
